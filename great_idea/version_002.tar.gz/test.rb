puts 3 + 3
